#!/bin/bash
set -e

source /opt/ros/humble/setup.bash

# DDS e dominio (DEVE matchare Create 3)
export ROS_DOMAIN_ID=0
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp

# Usa configurazione Fast DDS custom
export FASTRTPS_DEFAULT_PROFILES_FILE=/fastdds.xml

exec "$@"
